package com.bukachuda.ai;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class BukachudaAccessibilityService extends AccessibilityService {
    private static BukachudaAccessibilityService instance;
    public static BukachudaAccessibilityService getInstance() { return instance; }
    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    public void goHome() { performGlobalAction(GLOBAL_ACTION_HOME); }
    public void goBack() { performGlobalAction(GLOBAL_ACTION_BACK); }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }
}
