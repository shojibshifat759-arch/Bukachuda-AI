package com.bukachuda.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import android.view.*;
import android.graphics.Color;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, transcript;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean femaleVoice = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setBackgroundColor(Color.rgb(9,7,19));

        TextView title = new TextView(this);
        title.setText("বুকাচুদা AI 🤖");
        title.setTextSize(30); title.setTextColor(Color.rgb(0,229,255));
        page.addView(title);

        status = new TextView(this);
        status.setText("কী রে বস! কী করতে হবে? 😂");
        status.setTextColor(Color.WHITE); status.setTextSize(18);
        status.setPadding(0,24,0,18); page.addView(status);

        transcript = new TextView(this);
        transcript.setText("তোমার কথা এখানে দেখা যাবে");
        transcript.setTextColor(Color.LTGRAY); page.addView(transcript);

        Button listen = new Button(this); listen.setText("🎤 কথা বলো");
        page.addView(listen);
        Button voice = new Button(this); voice.setText("ভয়েস বদলাও: ছেলে / মেয়ে");
        page.addView(voice);
        Button accessibility = new Button(this); accessibility.setText("Accessibility চালু করার সেটিংস");
        page.addView(accessibility);

        setContentView(page);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn", "BD"));
        });
        listen.setOnClickListener(v -> startListening());
        voice.setOnClickListener(v -> {
            femaleVoice = !femaleVoice;
            status.setText(femaleVoice ? "মেয়ে ভয়েস নির্বাচন করা হয়েছে (যদি ফোনে থাকে)।" : "ছেলে ভয়েস নির্বাচন করা হয়েছে (যদি ফোনে থাকে)।");
            speak(status.getText().toString());
        });
        accessibility.setOnClickListener(v -> startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS")));
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("এই ফোনে Speech Recognition পাওয়া যাচ্ছে না।");
            return;
        }
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 10); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("শুনছি... বলো বস!"); }
            public void onResults(Bundle r) {
                ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (a != null && !a.isEmpty()) handleCommand(a.get(0));
            }
            public void onError(int e) { status.setText("আবার চেষ্টা করো। ইন্টারনেট/মাইক্রোফোন পরীক্ষা করো।"); }
            public void onBeginningOfSpeech() {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onEvent(int t, Bundle p) {}
            public void onPartialResults(Bundle p) {}
            public void onRmsChanged(float v) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
        recognizer.startListening(i);
    }

    private void handleCommand(String raw) {
        String s = raw.toLowerCase(Locale.ROOT);
        transcript.setText("তুমি বলেছ: " + raw);
        if (s.contains("youtube") || s.contains("ইউটিউব")) {
            openApp("com.google.android.youtube", "YouTube খুলে দিলাম।");
        } else if (s.contains("facebook") || s.contains("ফেসবুক")) {
            openApp("com.facebook.katana", "Facebook খুলে দিলাম।");
        } else if (s.contains("ফোন বন্ধ") || s.contains("অ্যাপ বন্ধ") || s.contains("বের হও")) {
            BukachudaAccessibilityService a = BukachudaAccessibilityService.getInstance();
            if (a != null) { a.goHome(); speak("হোম স্ক্রিনে চলে গেলাম, বস!"); }
            else speak("Accessibility চালু করলে Home-এ নিতে পারব।");
        } else if (s.contains("পেছনে") || s.contains("ব্যাক")) {
            BukachudaAccessibilityService a = BukachudaAccessibilityService.getInstance();
            if (a != null) { a.goBack(); speak("ব্যাক করলাম!"); }
            else speak("Accessibility চালু করো আগে।");
        } else {
            speak("হুম, শুনলাম বস! এই কমান্ডটা এখনো শেখানো হয়নি।");
        }
    }

    private void openApp(String pkg, String msg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) { startActivity(launch); speak(msg); }
        else speak("অ্যাপটা ফোনে ইনস্টল করা নেই, বস!");
    }
    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bukachuda");
    }
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
