বুকাচুদা AI - Android সোর্স প্রজেক্ট (প্রাথমিক সংস্করণ)

যা কাজ করে:
- অ্যাপ খোলা অবস্থায় বোতাম চেপে বাংলা ভয়েস কমান্ড শোনা
- YouTube ও Facebook চালু করা (ইনস্টল থাকলে)
- Accessibility Service চালু থাকলে Home/Back নেভিগেশন
- ফোনের Text-to-Speech ইঞ্জিনে উত্তর বলা

যা এখনো তৈরি হয়নি:
- অ্যাপ বন্ধ/স্ক্রিন বন্ধ অবস্থায় "এই বুকাচুদা" wake-word detection
- YouTube-কে জোর করে Force Stop করা (Android সাধারণ অ্যাপকে এটি করতে দেয় না)
- পূর্ণ ChatGPT-ধরনের AI backend / ওয়েব সার্চ / দীর্ঘমেয়াদি মেমোরি
- ছেলে/মেয়ে ভয়েস নিশ্চিত করা: এটি ফোনে ইনস্টল থাকা TTS voice-এর ওপর নির্ভর করে; বোতামটি আপাতত পছন্দের টগল।
- APK ফাইল: এই ZIP-এ সোর্স কোড আছে, তৈরি APK নয়।

তৈরি/বিল্ড:
1. Android Studio-তে এই ফোল্ডার Open করুন।
2. Gradle sync সম্পন্ন করুন।
3. Build > Build APK(s) নির্বাচন করুন।
4. ফোনে ইনস্টল করে Microphone permission দিন।
5. Accessibility সেটিংসে "বুকাচুদা AI" চালু করুন।

গুরুত্বপূর্ণ:
- ভয়েস recognition সাধারণত Android-এর speech recognition provider ও ইন্টারনেট ব্যবহার করতে পারে।
- অ্যাপটি কোনো গোপন রেকর্ডিং করে না; শোনার জন্য অ্যাপের বোতাম চাপতে হয়।
- Accessibility permission কেবল ঘোষিত Home/Back নেভিগেশনের জন্য।
